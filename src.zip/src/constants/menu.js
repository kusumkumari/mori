/* eslint-disable */

let data = []

  data = [{
    id: "dashboards",
    icon: "iconsminds-dashboard",
    label: "menu.dashboards",
    to: "/",
    
  },
  {
    id: "devices",
    icon: "iconsminds-smartphone-3",
    label: "menu.devices",
    to: "/device",
  },
  {
    id: "maintanance",
    icon: "iconsminds-engineering",
    label: "menu.maintainance-person",
    to: "/maintanance-person",
  },
  {
    id: "location",
    icon: "iconsminds-location-2",
    label: "menu.location",
    to: "/location",
  },
  {
    id: "task",
    icon: "iconsminds-wrench",
    label: "menu.task-creation",
    to: "/task-creation",
  },
  
  // {
  //   id: "categorys",
  //   icon: "iconsminds-data-center",
  //   label: "menu.categorys",
  //   to: "/category",
  //   subs: [{
  //     icon: "iconsminds-cookies",
  //     label: "menu.food-list",
  //     to: "/food/"
  //   },
  //   {
  //     icon: "simple-icon-briefcase",
  //     label: "menu.categorys-list",
  //     to: "/category/"
  //   },
  //   {
  //     icon: "simple-icon-screen-desktop",
  //     label: "menu.sub-list",
  //     to: "/subcategory/"
  //   },
  //   {
  //     icon: "iconsminds-shop",
  //     label: "menu.outlet-list",
  //     to: "/outlet/"
  //   },
  //   {
  //     icon: "simple-icon-paper-plane",
  //     label: "menu.variant-list",
  //     to: "/variant/"
  //   },
  //   {
  //     icon: "simple-icon-arrow-up-circle",
  //     label: "menu.addongroup-list",
  //     to: "/addongroup/"
  //   },
  //   {
  //     icon: "simple-icon-plus",
  //     label: "menu.addon-list",
  //     to: "/addon/"
  //   },
  //   {
  //     icon: "simple-icon-list",
  //     label: "menu.product",
  //     to: "/product/"
  //   },
  //   {
  //     icon: "simple-icon-note",
  //     label: "menu.feature-product",
  //     to: "/feature-product/"
  //   },
  //   ]
  // },
  // {
  //   id: "discount",
  //   icon: "simple-icon-trophy",
  //   label: "menu.discount-engine",
  //   to: "/discount",
  //   subs: [{
  //     icon: "simple-icon-trophy",
  //     label: "menu.coupons",
  //     to: "/coupons/"
  //   },
  //   {
  //     icon: "simple-icon-tag",
  //     label: "menu.combo",
  //     to: "/combo/"
  //   },
  //   {
  //     icon: "simple-icon-share-alt",
  //     label: "menu.combo-percentage",
  //     to: "/combo_percentage/"
  //   },
  //   {
  //     icon: "iconsminds-letter-open",
  //     label: "menu.coupon-history",
  //     to: "/coupon-history/"
  //   }
  //   ]
  // },
 
  // {
  //   id: "orders",
  //   icon: "iconsminds-receipt-4",
  //   label: "menu.orders",
  //   to: "/orders",
  // },
  ];

export default data;