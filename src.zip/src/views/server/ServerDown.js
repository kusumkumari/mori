import React from 'react';
 
const ServerDown = () => {
  return (
   
        <img alt="Server Down" src={require("./server.jpg")} style={{margin:"0 auto", display:"block", height: "502px"}} />
     
  );
};

export default ServerDown;
